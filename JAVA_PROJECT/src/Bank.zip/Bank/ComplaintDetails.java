package Bank;

public class ComplaintDetails {

String dateReceived;
String product;
String subProduct;
String issue;
String subIssue;
String company;
String state;
String ZIPcode;
String submittedVia;
String dateSentToCompany;
String companyResponseToConsumer;
String timelyResponse;
String consumerDisputed;
}